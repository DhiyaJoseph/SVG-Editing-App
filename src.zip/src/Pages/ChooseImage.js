import React from 'react'


export default function ChooseImage() {
  return (
    <div>
      
    </div>
  )
}
